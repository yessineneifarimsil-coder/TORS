from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
MODULE = ROOT / "src" / "v2_2_d2_8_numerical_null.py"


def load():
    spec = importlib.util.spec_from_file_location(
        "d28_test_module",
        MODULE,
    )
    if spec is None or spec.loader is None:
        raise ImportError(MODULE)
    module = importlib.util.module_from_spec(spec)
    sys.modules["d28_test_module"] = module
    spec.loader.exec_module(module)
    return module


d28 = load()


def test_null_matrix_is_exactly_multiplicatively_separable():
    rng = np.random.default_rng(
        np.random.SeedSequence([76001, 6])
    )
    x = d28.make_null_matrix(rng, 6)

    ratio = x[:, 0] / x[:, 1]
    assert np.std(np.log(ratio), ddof=0) < 1e-12


def test_null_structural_metrics_are_numerically_small():
    rng = np.random.default_rng(
        np.random.SeedSequence([76001, 5])
    )
    x = d28.make_null_matrix(rng, 5)

    assert abs(d28.rank_one_energy(x)) < 1e-10
    assert d28.max_pairwise_lrv(x) < 1e-10
    assert d28.d27.nsv(x, "vector") < 1e-8


def test_frozen_null_design_constants():
    assert d28.NULL_MASTER_SEED == 76001
    assert d28.ACTIVE_COUNTS == (5, 6)
    assert d28.NULL_REPLICATES_PER_COUNT == 2000
    assert d28.N_CONTEXTS == 1000
    assert d28.ENERGY_FLOOR == 1e-24
    assert d28.FLOOR_NS == 1e-12
    assert d28.FLOOR_LRV == 1e-10
    assert d28.FLOOR_NSV == 1e-10
    assert d28.HISTORICAL_DESIGN_SEEDS == (
        21001,
        21002,
        21003,
        21004,
        21005,
    )
    assert d28.HISTORICAL_RHO == 0.4
    assert d28.HISTORICAL_CRITERIA == (
        "C1",
        "C2",
        "C3",
        "C4",
        "C5",
        "C6",
        "C7",
    )


def test_rank_one_energy_rejects_structural_zero_energy():
    x = np.zeros((1000, 6), dtype=float)

    try:
        d28.rank_one_energy(x)
    except ValueError as exc:
        assert "structural-zero-energy" in str(exc)
    else:
        raise AssertionError(
            "Expected structural-zero-energy ValueError"
        )

def test_active_only_null_metrics_remain_below_frozen_floors():
    rng = np.random.default_rng(
        np.random.SeedSequence([76001, 5])
    )
    x = d28.make_null_matrix(rng, 5)

    assert d28.rank_one_energy(x) <= d28.FLOOR_NS
    assert d28.max_pairwise_lrv(x) <= d28.FLOOR_LRV
    assert d28.d27.nsv(x, "vector") <= 1e-8

